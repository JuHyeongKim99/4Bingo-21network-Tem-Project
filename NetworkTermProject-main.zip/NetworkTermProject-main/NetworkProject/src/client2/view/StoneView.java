package client2.view;

class StoneView{

    private int color;

    StoneView(int color) {
        this.color = color;
    }

    public int getColor() {
        return color;
    }
}
