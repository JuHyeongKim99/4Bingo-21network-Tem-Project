package client2.view;

import processing.core.PApplet;

public interface Displayable {
    void display(PApplet p);
}
