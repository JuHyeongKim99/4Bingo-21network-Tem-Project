package client2.protocol;

public class CountDownNum {

    private int countDownNum;

    public CountDownNum(int countDownNum) {
        this.countDownNum = countDownNum;
    }

    public int getCountDown() {
        return countDownNum;
    }
}
