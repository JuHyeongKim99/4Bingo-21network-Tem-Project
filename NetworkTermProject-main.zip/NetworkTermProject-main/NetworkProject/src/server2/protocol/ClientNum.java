package server2.protocol;

public class ClientNum {

    private int clientNum;

    public ClientNum(int clientNum) {
        this.clientNum = clientNum;
    }

    public void setClientNum(int clientNum) {
        this.clientNum = clientNum;
    }

    public int getClientNum() {
        return clientNum;
    }
}
