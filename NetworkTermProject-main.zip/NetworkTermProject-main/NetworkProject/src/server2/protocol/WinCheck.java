package server2.protocol;

public class WinCheck {
    private boolean winCheck;

    public WinCheck(boolean winCheck) {
        this.winCheck = winCheck;
    }

    public boolean getWinCheck() {
        return winCheck;
    }

}
